export { default as LandingPage } from './LandingPage';
export { default as Login } from './Login';
export { default as Register } from './Register';
export { default as ForgotPassword } from './ForgotPassword';
export { default as Module1 } from './Module1';
export { default as Module2 } from './Module2';
export { default as Module3 } from './Module3';
export { default as ModuleN } from './ModuleN';
export { default as ModuleNChild1 } from './ModuleNChild1';
export { default as ModuleNChild2 } from './ModuleNChild2';
export { default as ModuleNChild3 } from './ModuleNChild3';
export { default as Profile } from './Profile';
export { default as Dashboard } from './Dashboard';

